<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class TeacherService extends Model
{
    use HasFactory;

    protected $fillable = [
        'userServiceId',
        'appointmentSubjectId',
        'mainSubjectId',
        'appointmentMediumId',
        'appointmentCategoryId',
        'active',
    ];

    public function userService(): BelongsTo
    {
        return $this->belongsTo(UserInService::class, 'userServiceId', 'id');
    }

    public function appointmentSubject(): BelongsTo
    {
        return $this->belongsTo(Subject::class, 'appointmentSubjectId', 'id');
    }

    public function mainSubject(): BelongsTo
    {
        return $this->belongsTo(Subject::class, 'mainSubjectId', 'id');
    }
}
