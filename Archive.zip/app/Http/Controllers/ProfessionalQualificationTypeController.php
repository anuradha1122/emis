<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProfessionalQualificationTypeRequest;
use App\Http\Requests\UpdateProfessionalQualificationTypeRequest;
use App\Models\ProfessionalQualificationType;

class ProfessionalQualificationTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreProfessionalQualificationTypeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ProfessionalQualificationType $professionalQualificationType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ProfessionalQualificationType $professionalQualificationType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateProfessionalQualificationTypeRequest $request, ProfessionalQualificationType $professionalQualificationType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ProfessionalQualificationType $professionalQualificationType)
    {
        //
    }
}
