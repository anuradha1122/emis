<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreDsDivisionRequest;
use App\Http\Requests\UpdateDsDivisionRequest;
use App\Models\DsDivision;

class DsDivisionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDsDivisionRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DsDivision $dsDivision)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DsDivision $dsDivision)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDsDivisionRequest $request, DsDivision $dsDivision)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DsDivision $dsDivision)
    {
        //
    }
}
