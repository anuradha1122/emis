<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSchoolFacilityRequest;
use App\Http\Requests\UpdateSchoolFacilityRequest;
use App\Models\SchoolFacility;

class SchoolFacilityController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSchoolFacilityRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SchoolFacility $schoolFacility)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SchoolFacility $schoolFacility)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSchoolFacilityRequest $request, SchoolFacility $schoolFacility)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SchoolFacility $schoolFacility)
    {
        //
    }
}
