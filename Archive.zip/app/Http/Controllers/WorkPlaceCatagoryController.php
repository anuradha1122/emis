<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreworkPlaceCatagoryRequest;
use App\Http\Requests\UpdateworkPlaceCatagoryRequest;
use App\Models\workPlaceCatagory;

class WorkPlaceCatagoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreworkPlaceCatagoryRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(workPlaceCatagory $workPlaceCatagory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(workPlaceCatagory $workPlaceCatagory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateworkPlaceCatagoryRequest $request, workPlaceCatagory $workPlaceCatagory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(workPlaceCatagory $workPlaceCatagory)
    {
        //
    }
}
