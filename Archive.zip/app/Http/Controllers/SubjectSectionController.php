<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSubjectSectionRequest;
use App\Http\Requests\UpdateSubjectSectionRequest;
use App\Models\SubjectSection;

class SubjectSectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSubjectSectionRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SubjectSection $subjectSection)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SubjectSection $subjectSection)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSubjectSectionRequest $request, SubjectSection $subjectSection)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SubjectSection $subjectSection)
    {
        //
    }
}
