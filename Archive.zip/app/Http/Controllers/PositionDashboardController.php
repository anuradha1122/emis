<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePositionDashboardRequest;
use App\Http\Requests\UpdatePositionDashboardRequest;
use App\Models\PositionDashboard;

class PositionDashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePositionDashboardRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PositionDashboard $positionDashboard)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PositionDashboard $positionDashboard)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePositionDashboardRequest $request, PositionDashboard $positionDashboard)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PositionDashboard $positionDashboard)
    {
        //
    }
}
