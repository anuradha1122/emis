<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('subjects', function (Blueprint $table) {
            $table->id();

            $table->string('name', 200);

            // Foreign key to subject_sections
            $table->foreignId('sectionId')
                  ->constrained('subject_sections')
                  ->restrictOnDelete();

            // Foreign key to subject_categories
            $table->foreignId('categoryId')
                  ->constrained('subject_categories')
                  ->restrictOnDelete();

            // Optional weekly period
            $table->mediumInteger('weekPeriod')->unsigned()->nullable();

            // Active flag
            $table->boolean('active')->default(true);

            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('subjects');
    }
};
